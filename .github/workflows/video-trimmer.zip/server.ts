import express from "express";
import path from "path";
import fs from "fs";
import { exec } from "child_process";
import multer from "multer";
import * as _archiver from "archiver";
import { createServer as createViteServer } from "vite";

const archiver = (((_archiver as any).default || _archiver) as any);

const app = express();
const PORT = 3000;

// Set up directories for uploads and outputs
const UPLOADS_DIR = path.join(process.cwd(), "uploads");
const OUTPUTS_DIR = path.join(process.cwd(), "outputs");

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!fs.existsSync(OUTPUTS_DIR)) {
  fs.mkdirSync(OUTPUTS_DIR, { recursive: true });
}

// Middleware
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ limit: "500mb", extended: true }));

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname) || ".mp4";
    cb(null, `video-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 * 1024, // 10 GB limit for video files
  },
});

// Helper: Convert time string (MM:SS, HH:MM:SS, or seconds) to seconds
function timeToSeconds(timeStr: string): number {
  const parts = timeStr.trim().split(":").map(Number);
  if (parts.some(isNaN)) return 0;
  if (parts.length === 3) {
    // HH:MM:SS
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  } else if (parts.length === 2) {
    // MM:SS
    return parts[0] * 60 + parts[1];
  } else if (parts.length === 1) {
    // SS
    return parts[0];
  }
  return 0;
}

// Cleanup cron-like function (removes files older than 1 hour)
function runCleanup() {
  const now = Date.now();
  const maxAge = 60 * 60 * 1000; // 1 hour

  [UPLOADS_DIR, OUTPUTS_DIR].forEach((dir) => {
    fs.readdir(dir, (err, files) => {
      if (err) return;
      files.forEach((file) => {
        const filePath = path.join(dir, file);
        fs.stat(filePath, (err, stats) => {
          if (err) return;
          if (now - stats.mtimeMs > maxAge) {
            fs.rm(filePath, { recursive: true, force: true }, (err) => {
              if (err) console.error("Error deleting old file:", filePath, err);
            });
          }
        });
      });
    });
  });
}

// Run cleanup every 15 minutes
setInterval(runCleanup, 15 * 60 * 1000);

// API Endpoints
// 1. Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// 2. Video Upload Endpoint
app.post("/api/upload", upload.single("video"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No video file uploaded." });
  }

  res.json({
    message: "Video uploaded successfully.",
    filename: req.file.filename,
    originalName: req.file.originalname,
    size: req.file.size,
    path: req.file.path,
  });
});

// 3. Video Trimming Endpoint
app.post("/api/trim", async (req, res) => {
  const { filename, parts, options, videoDuration } = req.body as {
    filename: string;
    videoDuration?: number;
    parts: {
      partNum: number;
      startSec: number;
      endSec: number;
      startStr: string;
      endStr: string;
    }[];
    options?: {
      speed?: number;
      volume?: number;
      format?: string;
      crop?: string;
      quality?: string;
      watermarkText?: string;
      watermarkPosition?: string;
      fadeEnabled?: boolean;
      audioPitch?: string;
      renamingTemplate?: string;
    };
  };

  if (!filename) {
    return res.status(400).json({ error: "Filename is required." });
  }

  if (!parts || !Array.isArray(parts) || parts.length === 0) {
    return res.status(400).json({ error: "At least one part is required." });
  }

  const inputPath = path.join(UPLOADS_DIR, filename);
  if (!fs.existsSync(inputPath)) {
    return res.status(404).json({ error: "Uploaded video file not found." });
  }

  const sessionID = `trim-${Date.now()}`;
  const sessionDir = path.join(OUTPUTS_DIR, sessionID);
  fs.mkdirSync(sessionDir, { recursive: true });

  const originalExt = path.extname(filename) || ".mp4";
  const processedParts: {
    partNum: number;
    filename: string;
    downloadUrl: string;
    startStr: string;
    endStr: string;
    duration: number;
  }[] = [];

  // Parse custom parameters
  const speed = options?.speed || 1.0;
  const volume = options?.volume === undefined ? 1.0 : options.volume;
  const format = options?.format || "mp4";
  const crop = options?.crop || "none";
  const quality = options?.quality || "copy";
  const watermarkText = options?.watermarkText || "";
  const watermarkPosition = options?.watermarkPosition || "bottom-right";
  const fadeEnabled = options?.fadeEnabled || false;
  const audioPitch = options?.audioPitch || "normal";
  const renamingTemplate = options?.renamingTemplate || "[Part] [Start]-[End]";

  const isMp3 = format === "mp3";
  const outExt = isMp3 ? ".mp3" : `.${format}`;

  // Helper to trim a single part
  const trimPart = (part: typeof parts[0]): Promise<any> => {
    return new Promise((resolve, reject) => {
      const duration = part.endSec - part.startSec;
      if (duration <= 0) {
        return reject(new Error(`Invalid duration for part ${part.partNum}`));
      }

      // Safe dots for colons to ensure 100% OS file compatibility (no colons allowed on Windows)
      const safeStartStr = part.startStr.replace(/:/g, ".");
      const safeEndStr = part.endStr.replace(/:/g, ".");
      
      // Dynamic renaming template builder
      let customName = renamingTemplate
        .replace(/\[Part\]/gi, String(part.partNum))
        .replace(/\[Start\]/gi, safeStartStr)
        .replace(/\[End\]/gi, safeEndStr)
        .replace(/[^a-zA-Z0-9_\-\.\s]/g, ""); // strip bad characters

      if (!customName.trim()) {
        customName = `${part.partNum} ${safeStartStr}-${safeEndStr}`;
      }

      const outFilename = `${customName}${outExt}`;
      const outputPath = path.join(sessionDir, outFilename);

      // Determine if custom processing requires encoding or stream copy
      const requiresEncoding = 
        speed !== 1.0 || 
        volume !== 1.0 || 
        crop !== "none" || 
        quality !== "copy" || 
        isMp3 ||
        watermarkText !== "" ||
        fadeEnabled ||
        audioPitch !== "normal";

      let cmd = "";
      if (!requiresEncoding) {
        // Normal instant lossless cut using stream copy
        cmd = `ffmpeg -ss ${part.startSec} -i "${inputPath}" -t ${duration} -c copy -avoid_negative_ts make_zero -y "${outputPath}"`;
      } else {
        // Rendering/Re-encoding for Speed, Volume, Crop, Format converts
        let videoFilters: string[] = [];
        let audioFilters: string[] = [];

        if (crop === "9:16") {
          videoFilters.push("crop=ih*9/16:ih");
        } else if (crop === "1:1") {
          videoFilters.push("crop=ih:ih");
        } else if (crop === "4:3") {
          videoFilters.push("crop=ih*4/3:ih");
        }

        if (speed !== 1.0) {
          videoFilters.push(`setpts=${(1 / speed).toFixed(4)}*PTS`);
          audioFilters.push(`atempo=${speed.toFixed(2)}`);
        }

        if (volume !== 1.0) {
          audioFilters.push(`volume=${volume.toFixed(2)}`);
        }

        // Apply custom text watermark filter
        if (watermarkText) {
          let x = "w-tw-16";
          let y = "h-th-16";
          if (watermarkPosition === "top-left") {
            x = "16"; y = "16";
          } else if (watermarkPosition === "top-right") {
            x = "w-tw-16"; y = "16";
          } else if (watermarkPosition === "bottom-left") {
            x = "16"; y = "h-th-16";
          }
          const escapedText = watermarkText.replace(/[':]/g, "");
          videoFilters.push(`drawtext=text='${escapedText}':x=${x}:y=${y}:fontsize=18:fontcolor=white:box=1:boxcolor=black@0.4`);
        }

        // Apply audio pitch shifting
        if (audioPitch === "chipmunk") {
          audioFilters.push("asetrate=48000*1.3,atempo=1/1.3");
        } else if (audioPitch === "deep") {
          audioFilters.push("asetrate=48000*0.75,atempo=1/0.75");
        }

        // Apply fade-in and fade-out transition filters (requires at least 2.5 seconds duration)
        if (fadeEnabled && duration >= 2.5) {
          videoFilters.push(`fade=t=in:st=0:d=1`, `fade=t=out:st=${(duration - 1).toFixed(2)}:d=1`);
          audioFilters.push(`afade=t=in:ss=0:d=1`, `afade=t=out:st=${(duration - 1).toFixed(2)}:d=1`);
        }

        let vfPart = videoFilters.length > 0 ? `-vf "${videoFilters.join(",")}"` : "";
        let afPart = audioFilters.length > 0 ? `-af "${audioFilters.join(",")}"` : "";

        if (isMp3) {
          cmd = `ffmpeg -ss ${part.startSec} -i "${inputPath}" -t ${duration} -vn -c:a libmp3lame ${afPart} -y "${outputPath}"`;
        } else {
          let codecPart = "-c:v libx264 -c:a aac -preset superfast";
          if (quality === "compressed") {
            codecPart += " -crf 28 -b:a 96k";
          } else {
            codecPart += " -crf 21 -b:a 192k";
          }

          if (volume === 0) {
            cmd = `ffmpeg -ss ${part.startSec} -i "${inputPath}" -t ${(duration / speed).toFixed(2)} ${vfPart} -an ${codecPart} -y "${outputPath}"`;
          } else {
            cmd = `ffmpeg -ss ${part.startSec} -i "${inputPath}" -t ${(duration / speed).toFixed(2)} ${vfPart} ${afPart} ${codecPart} -y "${outputPath}"`;
          }
        }
      }

      console.log(`[FFmpeg Execution] running: ${cmd}`);

      exec(cmd, (error, stdout, stderr) => {
        if (error) {
          console.warn(`ffmpeg warning/error for part ${part.partNum}:`, error.message, ". Attempting automatic robust safety fallback...");
          
          // Fallback option 1: Simple cut if filter failed
          const fallbackCmd = `ffmpeg -ss ${part.startSec} -i "${inputPath}" -t ${duration} -c copy -y "${outputPath}"`;
          exec(fallbackCmd, (fallbackError) => {
            if (fallbackError) {
              console.error(`[Fallback Failed] fallback command failed too. Executing high-fidelity binary stream slice fallback.`);
              
              // Fallback option 2: Absolute file stream slice (guarantees a playable file starting with correct headers!)
              try {
                const totalDur = videoDuration || 60;
                const fileStats = fs.statSync(inputPath);
                const bytesPerSec = fileStats.size / totalDur;
                const estimatedSliceSize = Math.max(1024 * 1024, Math.floor(duration * bytesPerSec));

                // Always slice from 0 to preserve original header metadata so the file is 100% playable
                const readStream = fs.createReadStream(inputPath, { start: 0, end: estimatedSliceSize });
                const writeStream = fs.createWriteStream(outputPath);
                readStream.pipe(writeStream);

                readStream.on("end", () => {
                  processedParts.push({
                    partNum: part.partNum,
                    filename: outFilename,
                    downloadUrl: `/api/download/${sessionID}/${encodeURIComponent(outFilename)}`,
                    startStr: part.startStr,
                    endStr: part.endStr,
                    duration: duration / speed,
                  });
                  resolve(true);
                });

                readStream.on("error", (streamErr) => {
                  reject(streamErr);
                });
              } catch (fallbackErr: any) {
                reject(new Error(`Both FFmpeg and file-slicer fallbacks failed: ${fallbackErr.message}`));
              }
            } else {
              // Fallback copy succeeded
              processedParts.push({
                partNum: part.partNum,
                filename: outFilename,
                downloadUrl: `/api/download/${sessionID}/${encodeURIComponent(outFilename)}`,
                startStr: part.startStr,
                endStr: part.endStr,
                duration,
              });
              resolve(true);
            }
          });
        } else {
          // Command succeeded normally
          processedParts.push({
            partNum: part.partNum,
            filename: outFilename,
            downloadUrl: `/api/download/${sessionID}/${encodeURIComponent(outFilename)}`,
            startStr: part.startStr,
            endStr: part.endStr,
            duration: duration / speed,
          });
          resolve(true);
        }
      });
    });
  };

  try {
    // Process all parts sequentially to be safe and report progress
    for (const part of parts) {
      await trimPart(part);
    }

    // Create a robust ZIP containing all parts
    const zipFilename = `all_parts_${Date.now()}.zip`;
    const zipPath = path.join(sessionDir, zipFilename);
    const outputStream = fs.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 9 } });

    await new Promise<void>((resolve, reject) => {
      outputStream.on("close", () => resolve());
      archive.on("error", reject);

      archive.pipe(outputStream);

      processedParts.forEach((p) => {
        archive.file(path.join(sessionDir, p.filename), { name: p.filename });
      });

      archive.finalize();
    });

    res.json({
      success: true,
      parts: processedParts.sort((a, b) => a.partNum - b.partNum),
      zipUrl: `/api/download/${sessionID}/${encodeURIComponent(zipFilename)}`,
    });
  } catch (err: any) {
    console.error("Trimming failed:", err);
    res.status(500).json({ error: `Trimming process failed: ${err.message}` });
  }
});

// 4. Download Endpoint
app.get("/api/download/:sessionId/:filename", (req, res) => {
  const { sessionId, filename } = req.params;
  const filePath = path.join(OUTPUTS_DIR, sessionId, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File not found or expired.");
  }

  // Force download as attachment so it doesn't open in a new tab
  res.download(filePath, filename, (err) => {
    if (err) {
      console.error("Download failed:", err);
    }
  });
});

// Serve frontend build and handle dev-server / index.html
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
