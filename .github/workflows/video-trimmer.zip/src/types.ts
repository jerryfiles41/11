export interface VideoMetadata {
  name: string;
  size: number;
  type: string;
  duration: number; // in seconds
  width?: number;
  height?: number;
}

export interface ParsedPart {
  partNum: number;
  startStr: string;
  endStr: string;
  startSec: number;
  endSec: number;
  rawLine: string;
  isValid: boolean;
  error?: string;
}

export interface TrimmedPartResponse {
  partNum: number;
  filename: string;
  downloadUrl: string;
  startStr: string;
  endStr: string;
  duration: number;
}

export interface ProcessingState {
  status: "idle" | "uploading" | "trimming" | "completed" | "failed";
  uploadProgress: number; // 0 to 100
  currentTrimmingPart: number; // part index being trimmed
  error?: string;
}
