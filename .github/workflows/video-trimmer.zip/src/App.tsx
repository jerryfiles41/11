import React, { useState, useEffect, useRef } from "react";
import {
  UploadCloud,
  Scissors,
  FileVideo,
  CheckCircle2,
  Download,
  AlertTriangle,
  RefreshCw,
  FolderArchive,
  Play,
  Clock,
  HelpCircle,
  FileSpreadsheet,
  X,
  FileCode,
  Columns,
  LayoutGrid,
  Tv,
  AlignCenter,
  Type,
  Sliders,
  Sparkles,
} from "lucide-react";
import { VideoMetadata, ParsedPart, TrimmedPartResponse, ProcessingState } from "./types";
import { parsePrompt, secondsToTimeStr, formatBytes } from "./utils/parser";
import VideoPlayer from "./components/VideoPlayer";
import PartsVisualizer from "./components/PartsVisualizer";
import { trimSinglePartInBrowser, createZipBlob } from "./utils/browserTrimmer";

const DEFAULT_PROMPT = `part 1 0:10-0:25
part 2 0:35-0:50
part 3 1:05-1:15`;

interface Theme {
  id: string;
  name: string;
  primaryBg: string;
  dotColor: string;
}

const THEME_OPTIONS: Theme[] = [
  { id: "cyber-emerald", name: "Emerald Cyber", primaryBg: "bg-emerald-500", dotColor: "#10b981" },
  { id: "royal-amethyst", name: "Neon Amethyst", primaryBg: "bg-purple-500", dotColor: "#a855f7" },
  { id: "nordic-frost", name: "Nordic Frost", primaryBg: "bg-cyan-500", dotColor: "#06b6d4" },
  { id: "sunset-amber", name: "Sunset Amber", primaryBg: "bg-amber-500", dotColor: "#f59e0b" },
];

export default function App() {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoMetadata, setVideoMetadata] = useState<VideoMetadata | null>(null);
  const [promptText, setPromptText] = useState<string>(DEFAULT_PROMPT);
  const [parsedParts, setParsedParts] = useState<ParsedPart[]>([]);
  const [playbackTime, setPlaybackTime] = useState<number>(0);

  // Premium Trimmer States
  const [speed, setSpeed] = useState<number>(1.0);
  const [volume, setVolume] = useState<number>(1.0);
  const [format, setFormat] = useState<string>("mp4");
  const [crop, setCrop] = useState<string>("none");
  const [quality, setQuality] = useState<string>("copy");
  const [playbackRange, setPlaybackRange] = useState<{ start: number; end: number } | null>(null);

  // Advanced 6 Premium Feature States
  const [watermarkText, setWatermarkText] = useState<string>("");
  const [watermarkPosition, setWatermarkPosition] = useState<string>("bottom-right");
  const [fadeEnabled, setFadeEnabled] = useState<boolean>(false);
  const [audioPitch, setAudioPitch] = useState<string>("normal");
  const [renamingTemplate, setRenamingTemplate] = useState<string>("[Part] [Start]-[End]");

  // Multi-Layout State
  const [activeLayoutId, setActiveLayoutId] = useState<string>(() => {
    return localStorage.getItem("trim_layout_id") || "split";
  });

  const [activeThemeId, setActiveThemeId] = useState<string>(() => {
    return localStorage.getItem("trim_theme_id") || "cyber-emerald";
  });

  // Local Folder Selection States (FileSystem Access API)
  const [directoryHandle, setDirectoryHandle] = useState<any>(null);
  const [directoryName, setDirectoryName] = useState<string>("");

  const [simulationMode, setSimulationMode] = useState<boolean>(() => {
    return localStorage.getItem("trim_simulation_mode") === "true";
  });

  const [processing, setProcessing] = useState<ProcessingState>({
    status: "idle",
    uploadProgress: 0,
    currentTrimmingPart: 0,
  });

  const [result, setResult] = useState<{
    parts: TrimmedPartResponse[];
    zipUrl: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Update theme CSS variables dynamically
  useEffect(() => {
    localStorage.setItem("trim_theme_id", activeThemeId);
    
    let bgDark = "#0d0e12";
    let cardDark = "#161822";
    let accentGreen = "#10b981";
    let borderDark = "#252936";
    let textDim = "#94a3b8";

    if (activeThemeId === "royal-amethyst") {
      bgDark = "#090714";
      cardDark = "#140f2d";
      accentGreen = "#a855f7";
      borderDark = "#2e1e54";
      textDim = "#a78bfa";
    } else if (activeThemeId === "nordic-frost") {
      bgDark = "#0b111e";
      cardDark = "#151e33";
      accentGreen = "#06b6d4";
      borderDark = "#202e4d";
      textDim = "#94a3b8";
    } else if (activeThemeId === "sunset-amber") {
      bgDark = "#09090b";
      cardDark = "#18181b";
      accentGreen = "#f59e0b";
      borderDark = "#27272a";
      textDim = "#a1a1aa";
    }

    const root = document.documentElement;
    root.style.setProperty("--color-bg-dark", bgDark);
    root.style.setProperty("--color-card-dark", cardDark);
    root.style.setProperty("--color-accent-green", accentGreen);
    root.style.setProperty("--color-border-dark", borderDark);
    root.style.setProperty("--color-text-dim", textDim);
  }, [activeThemeId]);

  // Persist simulation mode choice & reset processing state to allow instant restarts
  useEffect(() => {
    localStorage.setItem("trim_simulation_mode", String(simulationMode));
    setResult(null);
    setProcessing({ status: "idle", uploadProgress: 0, currentTrimmingPart: 0 });
  }, [simulationMode]);

  // Persist layout choice
  useEffect(() => {
    localStorage.setItem("trim_layout_id", activeLayoutId);
  }, [activeLayoutId]);

  // Parse prompt text and validate whenever it or metadata changes
  useEffect(() => {
    const duration = videoMetadata?.duration || 0;
    const parts = parsePrompt(promptText, duration);
    setParsedParts(parts);
  }, [promptText, videoMetadata]);

  // Handle Drag events for video upload
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith("video/")) {
        setVideoFile(file);
        setVideoMetadata(null);
        setResult(null);
        setProcessing({ status: "idle", uploadProgress: 0, currentTrimmingPart: 0 });
      } else {
        alert("Ghalti! Barahe meherbani sirf video file select karein.");
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setVideoFile(file);
      setVideoMetadata(null);
      setResult(null);
      setProcessing({ status: "idle", uploadProgress: 0, currentTrimmingPart: 0 });
    }
  };

  const handleMetadataLoaded = (meta: VideoMetadata) => {
    setVideoMetadata(meta);
  };

  const handlePreviewPart = (seconds: number) => {
    setPlaybackTime(seconds);
  };

  const handleAutoSplit = (seconds: number) => {
    if (!videoMetadata || videoMetadata.duration <= 0) {
      alert("Barahe meherbani pehle koi video file select/upload karein.");
      return;
    }
    const duration = videoMetadata.duration;
    let promptStr = "";
    let partCount = 1;
    for (let t = 0; t < duration; t += seconds) {
      const end = Math.min(t + seconds, duration);
      if (end - t < 1.5) break; // skip trailing slice if under 1.5s
      promptStr += `part ${partCount} ${secondsToTimeStr(t)}-${secondsToTimeStr(end)}\n`;
      partCount++;
    }
    setPromptText(promptStr.trim());
  };

  const handleSelectFolder = async () => {
    try {
      if (!("showDirectoryPicker" in window)) {
        alert("Aapka browser modern Folder Select feature support nahi karta. Direct folder select karne ke liye Chrome, Edge, ya Opera use karein.");
        return;
      }
      const handle = await (window as any).showDirectoryPicker();
      const permissionStatus = await handle.requestPermission({ mode: "readwrite" });
      if (permissionStatus !== "granted") {
        alert("Directory write permission nahi mili. Files directly save nahi ki ja saken gi.");
        return;
      }
      setDirectoryHandle(handle);
      setDirectoryName(handle.name);
    } catch (err: any) {
      if (err.name !== "AbortError") {
        console.error("Folder selection failed:", err);
        alert(`Folder select karne me error aya: ${err.message || "Unknown error"}`);
      }
    }
  };

  const downloadAllConsecutively = async () => {
    if (!result || result.parts.length === 0) return;
    
    let savedToFolder = false;
    if (directoryHandle) {
      try {
        const permissionStatus = await directoryHandle.requestPermission({ mode: "readwrite" });
        if (permissionStatus === "granted") {
          for (const part of result.parts) {
            const response = await fetch(part.downloadUrl);
            const blob = await response.blob();
            
            const fileHandle = await directoryHandle.getFileHandle(part.filename, { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(blob);
            await writable.close();
          }
          savedToFolder = true;
          alert(`Mubarak ho! Tamam ${result.parts.length} clips directly aap ke selected folder "${directoryName}" me save ho gayi hain! 🎉`);
        }
      } catch (err: any) {
        console.error("Direct folder write failed:", err);
        alert(`Direct folder me save karne me error aya: ${err.message || "Unknown error"}. Standard downloads folder use ho rha hy.`);
      }
    }
    
    if (!savedToFolder) {
      // Loop through each part and trigger direct browser downloads in series
      for (const part of result.parts) {
        const link = document.createElement("a");
        link.href = part.downloadUrl;
        link.download = part.filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        // Wait 400ms to allow browser downloads queuing safely
        await new Promise((resolve) => setTimeout(resolve, 400));
      }
    }
  };

  // Run the full uploading & cutting process
  const startProcessing = () => {
    if (!videoFile) return;

    const validParts = parsedParts.filter((p) => p.isValid);
    if (validParts.length === 0) {
      setProcessing({
        status: "failed",
        uploadProgress: 0,
        currentTrimmingPart: 0,
        error: "Kash! Koi b valid part nahi mila. Apne prompt ko check karein (e.g. part 1 0:10-0:25).",
      });
      return;
    }

    setResult(null);

    // Bypasses network bottleneck for ultra-fast processing if simulation mode is active
    if (simulationMode) {
      setProcessing({
        status: "uploading",
        uploadProgress: 0,
        currentTrimmingPart: 0,
      });

      // Run browser trimming sequentially
      (async () => {
        try {
          const simulatedParts: TrimmedPartResponse[] = [];
          const filesToZip: { filename: string; blob: Blob }[] = [];

          for (let index = 0; index < validParts.length; index++) {
            const p = validParts[index];
            setProcessing({
              status: "trimming",
              uploadProgress: 0,
              currentTrimmingPart: index + 1,
            });

            const safeStartStr = p.startStr.replace(/:/g, ".");
            const safeEndStr = p.endStr.replace(/:/g, ".");
            
            // Render naming based on selected custom renaming template
            let customName = renamingTemplate
              .replace(/\[Part\]/gi, String(p.partNum))
              .replace(/\[Start\]/gi, safeStartStr)
              .replace(/\[End\]/gi, safeEndStr)
              .replace(/[^a-zA-Z0-9_\-\.\s]/g, "");

            if (!customName.trim()) {
              customName = `${p.partNum} ${safeStartStr}-${safeEndStr}`;
            }

            const isMp3 = format === "mp3";

            // Execute local high-speed browser canvas cutter
            const trimResult = await trimSinglePartInBrowser(
              videoFile,
              p.startSec,
              p.endSec,
              {
                speed,
                volume,
                format,
                crop,
                quality,
                watermarkText,
                watermarkPosition,
                fadeEnabled,
                audioPitch,
              },
              (percent) => {
                setProcessing((prev) => ({
                  ...prev,
                  uploadProgress: percent,
                }));
              }
            );

            const trimmedBlob = trimResult.blob;
            const actualExtension = trimResult.extension;
            const outFilename = `${customName}${actualExtension}`;

            const downloadUrl = URL.createObjectURL(trimmedBlob);

            simulatedParts.push({
              partNum: p.partNum,
              filename: outFilename,
              downloadUrl: downloadUrl,
              startStr: p.startStr,
              endStr: p.endStr,
              duration: (p.endSec - p.startSec) / speed,
            });

            filesToZip.push({
              filename: outFilename,
              blob: trimmedBlob,
            });
          }

          // Dynamic client-side ZIP building using JSZip
          const zipBlob = await createZipBlob(filesToZip);
          const zipUrl = URL.createObjectURL(zipBlob);

          setResult({
            parts: simulatedParts,
            zipUrl: zipUrl,
          });

          setProcessing({
            status: "completed",
            uploadProgress: 100,
            currentTrimmingPart: validParts.length,
          });

        } catch (err: any) {
          console.error("Browser trimming failed:", err);
          setProcessing({
            status: "failed",
            uploadProgress: 0,
            currentTrimmingPart: 0,
            error: `Browser trimming failed: ${err.message || "Unknown error occured"}`,
          });
        }
      })();

      return;
    }

    // Standard Real Backend Process
    setProcessing({ status: "uploading", uploadProgress: 0, currentTrimmingPart: 0 });

    const formData = new FormData();
    formData.append("video", videoFile);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload", true);

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.round((event.loaded / event.total) * 100);
        setProcessing((prev) => ({ ...prev, uploadProgress: percent }));
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const uploadRes = JSON.parse(xhr.responseText);
          const uploadedFilename = uploadRes.filename;

          setProcessing((prev) => ({
            ...prev,
            status: "trimming",
            uploadProgress: 100,
            currentTrimmingPart: 1,
          }));

          fetch("/api/trim", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              filename: uploadedFilename,
              videoDuration: videoMetadata?.duration || 0,
              parts: validParts.map((p) => ({
                partNum: p.partNum,
                startSec: p.startSec,
                endSec: p.endSec,
                startStr: p.startStr,
                endStr: p.endStr,
              })),
              options: {
                speed,
                volume,
                format,
                crop,
                quality,
                watermarkText,
                watermarkPosition,
                fadeEnabled,
                audioPitch,
                renamingTemplate,
              },
            }),
          })
            .then(async (response) => {
              if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.error || "Cutting failed.");
              }
              return response.json();
            })
            .then((trimRes) => {
              setResult({
                parts: trimRes.parts,
                zipUrl: trimRes.zipUrl,
              });
              setProcessing({
                status: "completed",
                uploadProgress: 100,
                currentTrimmingPart: validParts.length,
              });
            })
            .catch((err) => {
              setProcessing({
                status: "failed",
                uploadProgress: 100,
                currentTrimmingPart: 0,
                error: err.message || "Trimming fail ho gaya.",
              });
            });
        } catch (e) {
          setProcessing({
            status: "failed",
            uploadProgress: 100,
            currentTrimmingPart: 0,
            error: "Upload response parse karne me ghalti.",
          });
        }
      } else {
        setProcessing({
          status: "failed",
          uploadProgress: 100,
          currentTrimmingPart: 0,
          error: `Video upload fail ho gaya. Size checks verify karein (Max 100MB suggested over slow networks, otherwise switch to Ultra-Fast Simulation). Code: ${xhr.status}`,
        });
      }
    };

    xhr.onerror = () => {
      setProcessing({
        status: "failed",
        uploadProgress: 100,
        currentTrimmingPart: 0,
        error: "Server connection failure or payload too large limit exceeded by proxies.",
      });
    };

    xhr.send(formData);
  };

  const resetAll = () => {
    setVideoFile(null);
    setVideoMetadata(null);
    setPromptText(DEFAULT_PROMPT);
    setResult(null);
    setProcessing({ status: "idle", uploadProgress: 0, currentTrimmingPart: 0 });
  };

  const getOriginalExt = () => {
    if (!videoFile) return ".mp4";
    const name = videoFile.name;
    const lastDot = name.lastIndexOf(".");
    return lastDot !== -1 ? name.substring(lastDot) : ".mp4";
  };

  // Dynamic layout styling classes
  const getContainerGridClass = () => {
    if (activeLayoutId === "minimal") {
      return "flex flex-col gap-6 max-w-3xl mx-auto w-full";
    }
    return "grid grid-cols-1 lg:grid-cols-12 gap-6 items-start";
  };

  const getLeftColClass = () => {
    switch (activeLayoutId) {
      case "split":
        return "lg:col-span-7 space-y-4 w-full";
      case "bento":
        return "lg:col-span-8 space-y-4 bg-black/20 p-4 rounded-xl border border-border-dark w-full shadow-lg";
      case "cinema":
        return "lg:col-span-12 space-y-4 w-full";
      case "minimal":
      default:
        return "w-full space-y-4";
    }
  };

  const getRightColClass = () => {
    switch (activeLayoutId) {
      case "split":
        return "lg:col-span-5 space-y-4 w-full";
      case "bento":
        return "lg:col-span-4 space-y-4 bg-black/20 p-4 rounded-xl border border-border-dark w-full shadow-lg";
      case "cinema":
        return "lg:col-span-12 grid grid-cols-1 md:grid-cols-2 gap-6 items-start space-y-0 pt-2 w-full";
      case "minimal":
      default:
        return "w-full space-y-4";
    }
  };

  return (
    <div className="min-h-screen bg-bg-dark text-neutral-100 flex flex-col font-sans transition-colors duration-300 selection:bg-accent-green selection:text-neutral-950 tech-grid-bg">
      {/* Header */}
      <header className="border-b border-border-dark bg-black/90 sticky top-0 z-50 px-6 py-4 backdrop-blur-md">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-accent-green/10 border border-accent-green/30 rounded text-accent-green font-display text-sm font-bold tracking-tight">
              V-TRIM // ULTIMATE
            </div>
            <div>
              <h1 id="app-title" className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight flex items-center gap-2">
                Video Trimmer Studio
                <span className="text-[10px] font-sans font-medium uppercase bg-accent-green/10 border border-accent-green/20 text-accent-green px-2 py-0.5 rounded">
                  Lossless Stream copy
                </span>
              </h1>
              <p className="text-xs text-neutral-400 hidden sm:block">
                Trim video segments instantly without re-encoding and in 100% original quality
              </p>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-4">
            {/* Theme Picker */}
            <div className="flex items-center gap-2 bg-neutral-900/60 border border-border-dark px-3 py-1.5 rounded">
              <span className="text-[11px] text-neutral-400 font-medium">Theme:</span>
              <div className="flex items-center gap-1.5">
                {THEME_OPTIONS.map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => setActiveThemeId(theme.id)}
                    className={`w-4 h-4 rounded-full ${theme.primaryBg} transition-all relative ${
                      activeThemeId === theme.id ? "ring-2 ring-white scale-110" : "opacity-60 hover:opacity-100"
                    }`}
                    title={theme.name}
                  />
                ))}
              </div>
            </div>

            {/* Layout Preset Picker */}
            <div className="flex items-center gap-2 bg-neutral-900/60 border border-border-dark px-3 py-1.5 rounded">
              <span className="text-[11px] text-neutral-400 font-medium">Layout:</span>
              <div className="flex items-center gap-1.5">
                {[
                  { id: "split", name: "Classic Split", icon: Columns },
                  { id: "bento", name: "Bento Grid", icon: LayoutGrid },
                  { id: "cinema", name: "Theater Mode", icon: Tv },
                  { id: "minimal", name: "Vertical Focus", icon: AlignCenter },
                ].map((l) => {
                  const Icon = l.icon;
                  return (
                    <button
                      key={l.id}
                      onClick={() => setActiveLayoutId(l.id)}
                      className={`p-1 rounded text-neutral-400 hover:text-white transition-all cursor-pointer ${
                        activeLayoutId === l.id 
                          ? "bg-accent-green/20 text-accent-green border border-accent-green/30" 
                          : "border border-transparent hover:bg-neutral-800"
                      }`}
                      title={l.name}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Folder Selector (FileSystem Access API) */}
            {("showDirectoryPicker" in window) && (
              <button
                id="btn-select-folder-header"
                onClick={handleSelectFolder}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded border text-xs font-sans font-bold transition-all cursor-pointer ${
                  directoryHandle
                    ? "bg-accent-green/10 border-accent-green/40 text-accent-green"
                    : "bg-neutral-900/60 border-border-dark text-neutral-400 hover:text-white"
                }`}
                title={directoryName ? `Selected Folder: ${directoryName}` : "Select Download Folder"}
              >
                <FolderArchive className="w-3.5 h-3.5" />
                <span className="truncate max-w-[100px]">
                  {directoryName ? `${directoryName}` : "Set Folder"}
                </span>
              </button>
            )}

            {/* Run Mode Indicator */}
            <div className="text-xs font-sans text-accent-green flex items-center gap-2 bg-accent-green/5 border border-accent-green/20 px-3 py-1.5 rounded">
              <span className="w-2 h-2 rounded-full bg-accent-green animate-pulse"></span>
              <span className="uppercase font-semibold tracking-wider text-[11px]">System Online</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:py-8 space-y-6">
        
        {/* Step 1: Upload zone (displayed when no video is loaded) */}
        {!videoFile && (
          <div className="space-y-4">
            <div
              id="upload-container"
              ref={dragRef}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border border-dashed rounded p-10 sm:p-16 text-center cursor-pointer transition-all duration-300 flex flex-col items-center justify-center space-y-4 ${
                isDragging
                  ? "border-accent-green bg-accent-green/5 shadow-[0_0_30px_rgba(74,222,128,0.15)]"
                  : "border-border-dark bg-card-dark hover:border-accent-green/50 hover:bg-neutral-900/30"
              }`}
            >
              <input
                id="video-input"
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                accept="video/*"
                className="hidden"
              />
              <div className="p-4 bg-black border border-border-dark rounded text-accent-green group-hover:scale-105 transition-transform duration-300">
                <UploadCloud className="w-10 h-10" />
              </div>
              <div className="space-y-2 max-w-md">
                <span className="text-[11px] font-sans font-semibold uppercase tracking-wider text-accent-green block">Drag & Drop Your Video File</span>
                <h3 className="font-display font-extrabold text-xl text-white">
                  Source Video Select Karein
                </h3>
                <p className="text-xs text-neutral-400">
                  Click to select from your computer. Any duration up to <span className="text-accent-green font-bold">10 GB</span> is supported.
                </p>
                <p className="text-xs text-neutral-500 leading-relaxed pt-2 font-sans">
                  Lossless FFmpeg background stream technology will execute cuts in micro-seconds without degrading visual quality.
                </p>
              </div>
            </div>

            {/* Simulation/Ultra-fast mode warning during upload */}
            <div className="bg-card-dark border border-border-dark p-4 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span className="text-accent-green">🚀</span> Quick Demo & Simulation Mode (Recommended for testing)
                </h4>
                <p className="text-xs text-neutral-400 max-w-2xl">
                  Agar aap ki file barri hai (e.g. 100MB+) ya net slow hai to download/upload me time lag sakta hai. Is option se check karne ke liye simulation on karein jo baghair upload kiye instant result de gi!
                </p>
              </div>
              <div className="flex items-center gap-2 bg-black/40 border border-border-dark px-4 py-2.5 rounded shrink-0">
                <input
                  type="checkbox"
                  id="simulation-mode-toggle"
                  checked={simulationMode}
                  onChange={(e) => setSimulationMode(e.target.checked)}
                  className="w-4 h-4 rounded accent-accent-green cursor-pointer"
                />
                <label htmlFor="simulation-mode-toggle" className="text-xs font-semibold text-accent-green select-none cursor-pointer">
                  Ultra-Fast Demo Mode
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Main Workspace (when video is loaded) */}
        {videoFile && (
          <div className={getContainerGridClass()}>
            
            {/* Left: Video Player and Info */}
            <div className={getLeftColClass()}>
              <div className="flex justify-between items-center bg-card-dark p-3 rounded border border-border-dark">
                <div className="flex items-center gap-2">
                  <FileVideo className="w-4 h-4 text-accent-green" />
                  <span className="text-xs text-neutral-300 font-medium truncate max-w-[200px] sm:max-w-xs">
                    {videoFile.name}
                  </span>
                </div>
                <button
                  id="btn-change-video"
                  onClick={resetAll}
                  disabled={processing.status === "uploading" || processing.status === "trimming"}
                  className="px-2.5 py-1 rounded bg-black hover:bg-neutral-900 border border-border-dark text-[10px] text-neutral-300 font-sans font-bold flex items-center gap-1 transition-all disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  CHANGE VIDEO
                </button>
              </div>

              <VideoPlayer
                videoFile={videoFile}
                onMetadataLoaded={handleMetadataLoaded}
                onTimeUpdate={handlePreviewPart}
                playbackRange={playbackRange}
                onResetPlaybackRange={() => setPlaybackRange(null)}
              />

              {/* Dynamic Interactive Visual Timeline */}
              {videoMetadata && videoMetadata.duration > 0 && (
                <div className="bg-card-dark border border-border-dark p-4 rounded space-y-3">
                  <div className="flex justify-between items-center text-xs text-neutral-400">
                    <span className="font-display font-semibold text-white flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-accent-green" />
                      Visual Segment Timeline
                    </span>
                    <span className="font-mono text-neutral-400 bg-black px-2 py-0.5 rounded border border-border-dark">
                      Duration: {secondsToTimeStr(videoMetadata.duration)}
                    </span>
                  </div>

                  {/* Horizontal Segment Bar Track */}
                  <div className="relative h-7 bg-black rounded border border-border-dark overflow-hidden select-none">
                    {/* Render Highlighted Segment Boxes */}
                    {parsedParts.map((part, index) => {
                      if (!part.isValid) return null;
                      const leftPct = (part.startSec / videoMetadata.duration) * 100;
                      const widthPct = ((part.endSec - part.startSec) / videoMetadata.duration) * 100;

                      return (
                        <div
                          key={index}
                          style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                          className="absolute top-0 bottom-0 bg-accent-green/20 hover:bg-accent-green/35 border-l border-r border-accent-green/50 flex items-center justify-center cursor-pointer transition-all duration-150"
                          onClick={() => handlePreviewPart(part.startSec)}
                          title={`Part ${part.partNum}: ${part.startStr} - ${part.endStr} (${part.endSec - part.startSec}s)`}
                        >
                          <span className="text-[9px] font-mono font-bold text-accent-green truncate px-1">
                            P{part.partNum}
                          </span>
                        </div>
                      );
                    })}

                    {/* Current Playhead Line Indicator */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] transition-all duration-100"
                      style={{ left: `${(playbackTime / videoMetadata.duration) * 100}%` }}
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between text-[11px] text-neutral-500 gap-2">
                    <span>Click on any highlighted slice to seek video playhead</span>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded-sm bg-accent-green/20 border border-accent-green/50 inline-block" />
                        Selected Part
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-0.5 h-2.5 bg-red-500 inline-block" />
                        Playhead Location
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Urdu Prompt Guide Help Card */}
              <div className="bg-card-dark border border-border-dark p-4 rounded space-y-2">
                <h4 className="text-xs font-semibold text-accent-green tracking-wider uppercase font-sans flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4" /> Tarika-e-Kaar / Help & Instructions
                </h4>
                <ul className="text-xs text-neutral-400 space-y-1.5 list-disc pl-4 leading-relaxed font-sans">
                  <li><strong>Prompt Box:</strong> Har line par aik video clip ka timestamp likhein (e.g. <code className="text-accent-green font-mono font-bold bg-black/40 px-1 rounded">part 1 0:10-0:25</code>).</li>
                  <li><strong>Roman Urdu / Hindi:</strong> Aap normal likh sakte hain: "muje part 1 chahye jo 1:30 se 1:45 tak ho". Humara smart parser timestamps ko khud hi nikal le ga!</li>
                  <li><strong>Simulation Mode:</strong> Agar video heavy hai to timeline aur parts checking ke liye "Ultra-Fast Mode" on rakhein taake upload na karna parhe aur instantly download test ho sake.</li>
                  <li><strong>Renaming Scheme:</strong> Files automatic correctly rename ho ker save hon gi: <code className="text-accent-green font-mono">1 0.10-0.25.mp4</code>.</li>
                </ul>
              </div>
            </div>

            {/* Right: Trimming Rules Prompt Box and Visualizer */}
            <div className={getRightColClass()}>
              
              {/* Prompt Input Box */}
              <div className="bg-card-dark border border-border-dark rounded p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <label htmlFor="prompt-textarea" className="font-sans font-bold text-white flex items-center gap-2 text-xs uppercase tracking-wider">
                    <Scissors className="w-4 h-4 text-accent-green" />
                    Trim Logic Prompt
                  </label>
                  <span className="text-[10px] font-sans font-semibold text-neutral-400 bg-black border border-border-dark px-2 py-0.5 rounded">
                    Bilingual AI Parser
                  </span>
                </div>

                {/* Auto Status Splitter Buttons */}
                {videoMetadata && videoMetadata.duration > 0 && (
                  <div className="space-y-1 bg-black/40 border border-border-dark p-2 rounded">
                    <span className="text-[10px] font-sans font-semibold text-neutral-400 uppercase tracking-wider block">
                      ⚡ WhatsApp & Story Auto-Splitter (1-Click Slices):
                    </span>
                    <div className="grid grid-cols-3 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleAutoSplit(15)}
                        disabled={processing.status === "uploading" || processing.status === "trimming"}
                        className="py-1 px-1.5 rounded bg-black hover:bg-neutral-900 border border-border-dark text-[10px] font-sans font-bold text-accent-green hover:border-accent-green/40 transition-all cursor-pointer"
                        title="Video ko 15-seconds clips me auto divide karein"
                      >
                        15s (Insta Split)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAutoSplit(30)}
                        disabled={processing.status === "uploading" || processing.status === "trimming"}
                        className="py-1 px-1.5 rounded bg-black hover:bg-neutral-900 border border-border-dark text-[10px] font-sans font-bold text-accent-green hover:border-accent-green/44 transition-all cursor-pointer"
                        title="Video ko 30-seconds clips me auto divide karein"
                      >
                        30s (WhatsApp Split)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAutoSplit(60)}
                        disabled={processing.status === "uploading" || processing.status === "trimming"}
                        className="py-1 px-1.5 rounded bg-black hover:bg-neutral-900 border border-border-dark text-[10px] font-sans font-bold text-accent-green hover:border-accent-green/40 transition-all cursor-pointer"
                        title="Video ko 60-seconds clips me auto divide karein"
                      >
                        60s (Shorts Split)
                      </button>
                    </div>
                  </div>
                )}

                <div className="relative">
                  <textarea
                    id="prompt-textarea"
                    rows={6}
                    value={promptText}
                    onChange={(e) => setPromptText(e.target.value)}
                    disabled={processing.status === "uploading" || processing.status === "trimming"}
                    placeholder="Apna prompt yahan enter karein, e.g.:&#10;part 1 1:10-1:25&#10;part 2 2:13-2:27"
                    className="w-full bg-black border border-border-dark rounded p-3 text-sm font-mono text-accent-green focus:outline-none focus:ring-1 focus:ring-accent-green focus:border-accent-green placeholder-neutral-700 resize-none disabled:opacity-50"
                  />
                </div>

                {/* Simulated Mode Selector directly inside active panel */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-black/40 border border-border-dark p-2.5 rounded gap-2">
                  <div className="space-y-0.5 text-xs text-left">
                    <span className="text-white font-bold block">🚀 Select Speed Engine:</span>
                    <span className="text-[10px] text-neutral-400 block sm:max-w-xs">
                      {simulationMode 
                        ? "Ultra-Fast (Direct Local Slicing): 0-sec upload & download!" 
                        : "Fast Mode (Cloud Processing): Slices using background FFmpeg server."}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                    <button
                      onClick={() => {
                        setSimulationMode(false);
                        localStorage.setItem("trim_simulation_mode", "false");
                      }}
                      disabled={processing.status === "uploading" || processing.status === "trimming"}
                      className={`px-2.5 py-1.5 rounded text-[10px] font-bold uppercase transition-all cursor-pointer border ${
                        !simulationMode 
                          ? "bg-accent-green border-accent-green text-black shadow-lg" 
                          : "text-neutral-400 bg-black border-border-dark hover:text-white"
                      }`}
                    >
                      Fast (Cloud)
                    </button>
                    <button
                      onClick={() => {
                        setSimulationMode(true);
                        localStorage.setItem("trim_simulation_mode", "true");
                      }}
                      disabled={processing.status === "uploading" || processing.status === "trimming"}
                      className={`px-2.5 py-1.5 rounded text-[10px] font-bold uppercase transition-all cursor-pointer border ${
                        simulationMode 
                          ? "bg-accent-green border-accent-green text-black shadow-lg" 
                          : "text-neutral-400 bg-black border-border-dark hover:text-white"
                      }`}
                    >
                      Ultra-Fast (Browser)
                    </button>
                  </div>
                </div>

                {/* Real-time Validation & Trigger Button */}
                {processing.status === "idle" && (
                  <button
                    id="btn-start-trim"
                    onClick={startProcessing}
                    disabled={parsedParts.filter((p) => p.isValid).length === 0}
                    className="w-full py-3 px-4 rounded bg-accent-green hover:opacity-95 text-black font-sans font-bold text-xs uppercase tracking-wider transition-all active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:hover:bg-accent-green shadow-lg shadow-accent-green/10 cursor-pointer"
                  >
                    <Scissors className="w-4 h-4 fill-current" />
                    {simulationMode ? "Start Ultra-Fast Slicing" : "Start Lossless Slicing"}
                  </button>
                )}

                {/* Progress Indicators during Processing */}
                {(processing.status === "uploading" || processing.status === "trimming") && (
                  <div className="space-y-3 pt-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-sans font-semibold text-accent-green flex items-center gap-2 uppercase tracking-wide">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        {processing.status === "uploading"
                          ? (simulationMode ? "PREPARING_PLAYABLE_CLIPS" : "UPLOADING_VIDEO_FILE")
                          : "PROCESSING_SPLIT_SECTOR"}
                      </span>
                      <span className="font-mono text-neutral-400">
                        {processing.status === "uploading" ? `${processing.uploadProgress}%` : "READY!"}
                      </span>
                    </div>

                    {/* Progress Bar Container */}
                    <div className="h-2 w-full bg-black rounded-full overflow-hidden border border-border-dark">
                      <div
                        className="h-full bg-accent-green rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(74,222,128,0.5)]"
                        style={{
                          width: `${
                            processing.status === "uploading"
                              ? processing.uploadProgress
                              : 100
                          }%`,
                        }}
                      ></div>
                    </div>

                    <p className="text-[10px] text-neutral-500 text-center leading-relaxed font-mono uppercase tracking-wider">
                      {processing.status === "uploading"
                        ? `Extracting streams. Size: ${formatBytes(videoFile.size)}`
                        : `Applying premium modifiers & slicing segments cleanly.`}
                    </p>
                  </div>
                )}

                {/* Error Banner */}
                {processing.status === "failed" && (
                  <div className="bg-red-500/10 border border-red-500/20 p-3 rounded flex items-start gap-2.5">
                    <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="text-xs font-sans font-bold text-red-400 uppercase">Trimming Error</h4>
                      <p className="text-xs text-neutral-300 leading-relaxed font-sans">{processing.error}</p>
                      <button
                        id="btn-retry"
                        onClick={() => setProcessing({ status: "idle", uploadProgress: 0, currentTrimmingPart: 0 })}
                        className="text-xs text-accent-green hover:underline font-sans font-bold block pt-1 cursor-pointer"
                      >
                        RETRY / FORMAT THIK KAREIN
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Premium Processing Options Panel */}
              <div className="bg-card-dark border border-border-dark rounded p-4 space-y-4">
                <h4 className="font-sans font-bold text-white text-xs uppercase tracking-wider flex items-center gap-2">
                  <span className="text-accent-green">⚙️</span> Premium Editing Controls
                </h4>
                
                <div className="grid grid-cols-2 gap-4">
                  {/* Option 1: Playback Speed */}
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                      🏃 Speed Multiplier
                    </label>
                    <select
                      value={speed}
                      onChange={(e) => setSpeed(parseFloat(e.target.value))}
                      className="w-full bg-black border border-border-dark rounded p-1.5 text-xs text-neutral-200 font-sans focus:outline-none focus:ring-1 focus:ring-accent-green focus:border-accent-green cursor-pointer"
                    >
                      <option value={0.5}>0.5x (Slow Mo)</option>
                      <option value={1.0}>1.0x (Normal)</option>
                      <option value={1.5}>1.5x (Fast)</option>
                      <option value={2.0}>2.0x (Double Speed)</option>
                    </select>
                  </div>

                  {/* Option 2: Volume Booster */}
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                      🔊 Volume Booster
                    </label>
                    <select
                      value={volume}
                      onChange={(e) => setVolume(parseFloat(e.target.value))}
                      className="w-full bg-black border border-border-dark rounded p-1.5 text-xs text-neutral-200 font-sans focus:outline-none focus:ring-1 focus:ring-accent-green focus:border-accent-green cursor-pointer"
                    >
                      <option value={0}>🔇 Muted (Mute Clip)</option>
                      <option value={1.0}>🔊 100% (Normal)</option>
                      <option value={1.5}>🔊 150% (Louder)</option>
                      <option value={2.0}>🔊 200% (Super Boost)</option>
                    </select>
                  </div>

                  {/* Option 3: Format Extractor */}
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                      📁 Output Format
                    </label>
                    <select
                      value={format}
                      onChange={(e) => setFormat(e.target.value)}
                      className="w-full bg-black border border-border-dark rounded p-1.5 text-xs text-neutral-200 font-sans focus:outline-none focus:ring-1 focus:ring-accent-green focus:border-accent-green cursor-pointer"
                    >
                      <option value="mp4">MP4 (Standard Video)</option>
                      <option value="mkv">MKV (lossless stream)</option>
                      <option value="webm">WebM (Low-Size Clip)</option>
                      <option value="mp3">MP3 (Audio Only Extract)</option>
                    </select>
                  </div>

                  {/* Option 4: Social Aspect Ratio Crop */}
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                      📐 Aspect Crop (Socials)
                    </label>
                    <select
                      value={crop}
                      onChange={(e) => setCrop(e.target.value)}
                      className="w-full bg-black border border-border-dark rounded p-1.5 text-xs text-neutral-200 font-sans focus:outline-none focus:ring-1 focus:ring-accent-green focus:border-accent-green cursor-pointer"
                    >
                      <option value="none">Original Aspect Ratio</option>
                      <option value="9:16">9:16 (Portrait TikTok/Reels)</option>
                      <option value="1:1">1:1 (Square Instagram)</option>
                      <option value="4:3">4:3 (Classic TV)</option>
                    </select>
                  </div>
                </div>

                {/* Option 5: Quality Presets */}
                <div className="space-y-1 pt-1 border-t border-border-dark/60 text-left">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                    🌟 Quality Presets
                  </label>
                  <select
                    value={quality}
                    onChange={(e) => setQuality(e.target.value)}
                    className="w-full bg-black border border-border-dark rounded p-1.5 text-xs text-neutral-200 font-sans focus:outline-none focus:ring-1 focus:ring-accent-green focus:border-accent-green cursor-pointer"
                  >
                    <option value="copy">Super Fast Stream Copy (Lossless / Fast)</option>
                    <option value="compressed">Compressed (Low bandwidth & small size)</option>
                    <option value="high">High Quality (H.264 rendering / Best quality)</option>
                  </select>
                </div>
              </div>

              {/* Dynamic Cuts Visualizer */}
              <PartsVisualizer
                parts={parsedParts}
                originalExt={format === "mp3" ? ".mp3" : `.${format}`}
                onPreviewRange={(start, end) => setPlaybackRange({ start, end })}
              />

              {/* Completed Results Panel */}
              {processing.status === "completed" && result && (
                <div className="bg-card-dark border border-accent-green/30 rounded p-5 space-y-4 animate-fade-in shadow-[0_0_20px_rgba(74,222,128,0.05)]">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-6 h-6 text-accent-green shrink-0" />
                    <div>
                      <h3 className="font-sans font-bold text-white text-sm uppercase tracking-wide">
                        SUCCESS // PROCESS_COMPLETED
                      </h3>
                      <p className="text-xs text-neutral-400 font-sans">
                        All segments have been cut instantly in full original quality!
                      </p>
                    </div>
                  </div>

                  {/* Modern Direct Folder Choice (FileSystem Access API) */}
                  {("showDirectoryPicker" in window) && (
                    <div className="p-3 bg-neutral-950 rounded border border-border-dark flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div className="space-y-0.5 text-left">
                        <span className="text-xs font-sans font-bold text-accent-green flex items-center gap-1">
                          📁 TARGET FOLDER (OPTIONAL DIRECT SAVING)
                        </span>
                        <p className="text-[10px] text-neutral-400 font-sans leading-relaxed">
                          {directoryHandle 
                            ? `Selected: "${directoryName}" (Files will save directly inside this folder!)` 
                            : "Apne computer ka koi bhi folder select karein taake splits directly wahan save hon bina browser prompts ke!"}
                        </p>
                      </div>
                      <button
                        id="btn-select-folder-results"
                        onClick={handleSelectFolder}
                        className={`w-full sm:w-auto px-4 py-2 rounded font-sans font-bold text-xs flex items-center justify-center gap-1.5 shadow transition-all active:scale-95 cursor-pointer ${
                          directoryHandle
                            ? "bg-black hover:bg-neutral-900 border border-accent-green text-accent-green"
                            : "bg-accent-green text-black hover:opacity-90"
                        }`}
                      >
                        <FolderArchive className="w-3.5 h-3.5" />
                        {directoryHandle ? "CHANGE FOLDER" : "SELECT FOLDER"}
                      </button>
                    </div>
                  )}

                  {/* Custom direct folder simulated download (Consecutive files) */}
                  <div className="p-3 bg-black rounded border border-border-dark flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="space-y-0.5 text-left">
                      <span className="text-xs font-sans font-bold text-accent-green flex items-center gap-1">
                        📂 SAVE ALL DIRECTLY TO COMPUTER (NO ZIP)
                      </span>
                      <p className="text-[10px] text-neutral-400 font-sans leading-relaxed">
                        Apki browser downloads folder me tamam {result.parts.length} split clips alag alag save hon gi bina kisi ZIP extract kiye!
                      </p>
                    </div>
                    <button
                      id="btn-download-folder-simulated"
                      onClick={downloadAllConsecutively}
                      className="w-full sm:w-auto px-4 py-2 rounded bg-black hover:bg-neutral-900 border border-accent-green text-accent-green font-sans font-bold text-xs flex items-center justify-center gap-1.5 shadow transition-all active:scale-95 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      DOWNLOAD ALL
                    </button>
                  </div>

                  {/* Main ZIP Download */}
                  <div className="p-3 bg-black rounded border border-border-dark flex items-center justify-between gap-4">
                    <div className="space-y-0.5 text-left">
                      <span className="text-xs font-sans font-bold text-white flex items-center gap-1">
                        <FolderArchive className="w-3.5 h-3.5 text-accent-green" />
                        DOWNLOAD AS SINGLE ZIP FILE
                      </span>
                      <p className="text-[10px] text-neutral-500 font-sans">
                        Ek single standard compress ZIP package me download karein.
                      </p>
                    </div>
                    <a
                      id="btn-download-zip"
                      href={result.zipUrl}
                      download={`VideoTrimmer_${Date.now()}.zip`}
                      className="px-4 py-2 rounded bg-accent-green hover:opacity-90 text-black font-sans font-bold text-xs flex items-center gap-1.5 shadow transition-all active:scale-95 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      GET ZIP
                    </a>
                  </div>

                  {/* Individual Clips List */}
                  <div className="space-y-2 text-left">
                    <span className="text-xs font-semibold text-neutral-400 font-sans uppercase tracking-wider">
                      Or Download Individual Clips Manually:
                    </span>
                    <div className="space-y-1.5 max-h-[180px] overflow-y-auto pr-1">
                      {result.parts.map((p, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-2 rounded bg-black border border-border-dark text-xs"
                        >
                          <div className="truncate max-w-[260px] sm:max-w-xs pr-2 font-mono">
                            <span className="text-accent-green font-bold mr-1">{p.partNum}.</span>
                            <span className="text-neutral-300">{p.filename}</span>
                          </div>
                          <a
                            id={`btn-download-part-${p.partNum}`}
                            href={p.downloadUrl}
                            download={p.filename}
                            className="text-accent-green hover:text-white font-bold flex items-center gap-1 font-sans hover:underline shrink-0 text-[11px] cursor-pointer"
                          >
                            <Download className="w-3 h-3" />
                            DOWNLOAD
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Reset/Done Button */}
                  <button
                    id="btn-done"
                    onClick={resetAll}
                    className="w-full py-2.5 px-4 rounded border border-border-dark hover:border-accent-green/30 text-xs text-neutral-400 hover:text-accent-green font-sans font-bold tracking-wider transition-all cursor-pointer"
                  >
                    CLEAR WORKSPACE & NEW VIDEO
                  </button>
                </div>
              )}

            </div>

          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-border-dark bg-black py-4 text-center text-xs text-neutral-500 font-sans">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="uppercase tracking-wider text-[10px] text-neutral-400">
            ENGINE: FFMPEG_STREAM_COPY | CODES: 100% SECURE | NO API KEY REQUIRED
          </div>
          <span className="text-neutral-600">
            © 2026 VIDEO_TRIMMER_STUDIO
          </span>
        </div>
      </footer>
    </div>
  );
}
