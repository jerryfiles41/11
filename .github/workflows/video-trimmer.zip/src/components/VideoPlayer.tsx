import React, { useRef, useState, useEffect } from "react";
import { Play, Pause, RotateCcw, Film, Info, Clock } from "lucide-react";
import { VideoMetadata } from "../types";
import { secondsToTimeStr, formatBytes } from "../utils/parser";

interface VideoPlayerProps {
  videoFile: File;
  onMetadataLoaded: (metadata: VideoMetadata) => void;
  onTimeUpdate?: (time: number) => void;
  playbackRange?: { start: number; end: number } | null;
  onResetPlaybackRange?: () => void;
}

export default function VideoPlayer({
  videoFile,
  onMetadataLoaded,
  onTimeUpdate,
  playbackRange,
  onResetPlaybackRange,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [metadata, setMetadata] = useState<{
    width: number;
    height: number;
    size: number;
    type: string;
  } | null>(null);

  // Generate local object URL for the uploaded file so we can stream/play it locally instantly
  useEffect(() => {
    if (videoFile) {
      const url = URL.createObjectURL(videoFile);
      setVideoUrl(url);
      setIsPlaying(false);
      setCurrentTime(0);

      return () => {
        URL.revokeObjectURL(url);
      };
    }
  }, [videoFile]);

  // Handle seeking to a range and playing it dynamically
  useEffect(() => {
    if (playbackRange && videoRef.current) {
      const video = videoRef.current;
      video.currentTime = playbackRange.start;
      video.play().catch((err) => console.error("Play range error:", err));
      setIsPlaying(true);
    }
  }, [playbackRange]);

  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    if (!video) return;

    const meta: VideoMetadata = {
      name: videoFile.name,
      size: videoFile.size,
      type: videoFile.type || "video/mp4",
      duration: video.duration,
      width: video.videoWidth,
      height: video.videoHeight,
    };

    setDuration(video.duration);
    setMetadata({
      width: video.videoWidth,
      height: video.videoHeight,
      size: videoFile.size,
      type: videoFile.type || "video/mp4",
    });

    onMetadataLoaded(meta);
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;

    const curr = video.currentTime;
    setCurrentTime(curr);

    // If a preview range is active, check if we have hit the endpoint and automatically pause
    if (playbackRange && curr >= playbackRange.end) {
      video.pause();
      setIsPlaying(false);
      if (onResetPlaybackRange) {
        onResetPlaybackRange();
      }
    }

    if (onTimeUpdate) {
      onTimeUpdate(curr);
    }
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play().catch((err) => console.error("Error playing video:", err));
    }
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;
    const seekTime = parseFloat(e.target.value);
    video.currentTime = seekTime;
    setCurrentTime(seekTime);
  };

  const restartVideo = () => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = 0;
    setCurrentTime(0);
    if (!isPlaying) {
      video.play();
      setIsPlaying(true);
    }
  };

  const skipSeconds = (secs: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = Math.min(Math.max(0, video.currentTime + secs), duration);
  };

  return (
    <div className="bg-card-dark border border-border-dark rounded overflow-hidden shadow-2xl transition-all duration-300">
      <div className="p-4 bg-black border-b border-border-dark flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Film className="w-5 h-5 text-accent-green" />
          <span className="font-display font-medium text-white truncate max-w-[250px] sm:max-w-md">
            {videoFile.name}
          </span>
        </div>
        <div className="text-xs font-mono px-2 py-1 rounded bg-black border border-border-dark text-neutral-400">
          {formatBytes(videoFile.size)}
        </div>
      </div>

      {/* Video element */}
      <div className="relative bg-black aspect-video flex items-center justify-center">
        {videoUrl && (
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-full max-h-[480px] object-contain"
            onLoadedMetadata={handleLoadedMetadata}
            onTimeUpdate={handleTimeUpdate}
            onClick={togglePlay}
          />
        )}
      </div>

      {/* Controls */}
      <div className="p-4 bg-black/40 space-y-4">
        {/* Progress Bar & Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono text-neutral-400">
            <span className="text-accent-green font-medium">{secondsToTimeStr(currentTime)}</span>
            <span>{secondsToTimeStr(duration)}</span>
          </div>
          <div className="relative flex items-center">
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-2 roundedappearance-none cursor-pointer accent-accent-green bg-neutral-800 focus:outline-none"
            />
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={togglePlay}
              className="p-2.5 rounded bg-accent-green hover:opacity-90 text-black font-bold transition-all duration-200 active:scale-95 flex items-center justify-center shadow-lg shadow-accent-green/20 cursor-pointer"
              title={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            </button>
            <button
              onClick={restartVideo}
              className="p-2.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-all duration-200 flex items-center justify-center cursor-pointer"
              title="Restart"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => skipSeconds(-5)}
              className="px-2 py-1.5 rounded bg-black hover:bg-neutral-900 border border-border-dark text-xs font-mono text-neutral-300 transition-all duration-200 cursor-pointer"
              title="Rewind 5s"
            >
              -5s
            </button>
            <button
              onClick={() => skipSeconds(5)}
              className="px-2 py-1.5 rounded bg-black hover:bg-neutral-900 border border-border-dark text-xs font-mono text-neutral-300 transition-all duration-200 cursor-pointer"
              title="Fast Forward 5s"
            >
              +5s
            </button>
          </div>

          <div className="flex items-center gap-4 text-xs text-neutral-400 font-mono">
            {metadata && (
              <div className="flex items-center gap-2">
                <Info className="w-3.5 h-3.5 text-neutral-500" />
                <span>
                  {metadata.width}x{metadata.height}
                </span>
                <span className="text-neutral-700">|</span>
                <span>{metadata.type}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Timestamp Insertion Helpers */}
      <div className="px-4 py-3 bg-black/60 border-t border-border-dark flex justify-between gap-2">
        <div className="text-xs text-neutral-400 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-accent-green" />
          <span>Timestamps chahiye? Oper running clock se exact times copy karein!</span>
        </div>
        <div className="text-xs font-mono font-bold text-accent-green bg-accent-green/10 px-2 py-0.5 rounded border border-accent-green/20 animate-pulse">
          Current: {secondsToTimeStr(currentTime)}
        </div>
      </div>
    </div>
  );
}
