import { ParsedPart } from "../types";
import { secondsToTimeStr } from "../utils/parser";
import { CheckCircle2, AlertCircle, Eye, HelpCircle } from "lucide-react";

interface PartsVisualizerProps {
  parts: ParsedPart[];
  onPreviewRange?: (startSec: number, endSec: number) => void;
  originalExt?: string;
}

export default function PartsVisualizer({
  parts,
  onPreviewRange,
  originalExt = ".mp4",
}: PartsVisualizerProps) {
  const validPartsCount = parts.filter((p) => p.isValid).length;

  return (
    <div className="bg-card-dark border border-border-dark rounded overflow-hidden p-4 space-y-4">
      <div className="flex items-center justify-between border-b border-border-dark pb-3">
        <h3 className="font-display font-medium text-white flex items-center gap-2">
          Parsed Video Cuts <span className="text-xs text-neutral-400">({parts.length} total)</span>
        </h3>
        <div className="text-xs font-mono px-2 py-0.5 rounded bg-accent-green/10 border border-accent-green/20 text-accent-green">
          {validPartsCount} / {parts.length} Valid Parts Ready
        </div>
      </div>

      {parts.length === 0 ? (
        <div className="text-center py-6 text-neutral-500 text-sm space-y-1">
          <HelpCircle className="w-8 h-8 text-neutral-600 mx-auto" />
          <p>Apne prompt box me parts likhein taake cuts yahan nazar aayen.</p>
          <p className="text-xs text-neutral-600">e.g., "part 1 0:30-0:45" ya "part 2 1:15 to 1:30"</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
          {parts.map((part, index) => {
            const safeStartStr = part.startStr.replace(/:/g, ".");
            const safeEndStr = part.endStr.replace(/:/g, ".");
            const targetFilename = `${part.partNum} ${safeStartStr}-${safeEndStr}${originalExt}`;
            const durationSecs = part.endSec - part.startSec;

            return (
              <div
                key={index}
                className={`flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded border text-sm transition-all duration-200 ${
                  part.isValid
                    ? "bg-black/40 border-border-dark hover:border-accent-green/30"
                    : "bg-red-500/5 border-red-950/50 hover:bg-red-500/10"
                }`}
              >
                {/* Part Details */}
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    {part.isValid ? (
                      <CheckCircle2 className="w-4 h-4 text-accent-green shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                    )}
                    <span className="font-display font-semibold text-white">
                      Part {part.partNum}
                    </span>
                    {part.isValid && (
                      <span className="text-xs font-mono text-accent-green bg-accent-green/10 px-1.5 py-0.2 rounded">
                        {durationSecs} sec clip
                      </span>
                    )}
                  </div>

                  {part.isValid ? (
                    <div className="space-y-1">
                      <div className="text-xs text-neutral-400 font-mono">
                        Timestamps: <strong className="text-neutral-200">{part.startStr}</strong> → <strong className="text-neutral-200">{part.endStr}</strong>
                      </div>
                      <div className="text-xs font-mono text-neutral-500 flex items-center gap-1">
                        <span>Save Name:</span>
                        <code className="bg-black px-1.5 py-0.5 rounded border border-border-dark text-accent-green text-[11px] truncate max-w-[280px] sm:max-w-xs block">
                          {targetFilename}
                        </code>
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs text-red-400">
                      {part.error || "Ghalt format. Misal: 1:10-1:25"}
                    </div>
                  )}
                </div>

                {/* Preview / Actions */}
                {part.isValid && onPreviewRange && (
                  <button
                    onClick={() => onPreviewRange(part.startSec, part.endSec)}
                    className="mt-2 sm:mt-0 px-2.5 py-1.5 rounded bg-black hover:bg-neutral-900 border border-border-dark text-xs text-neutral-300 font-sans font-bold flex items-center justify-center gap-1.5 transition-all self-start sm:self-center cursor-pointer hover:border-accent-green/40 text-accent-green"
                    title="Is segment ka live preview daikhne ke liye click karein"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Seek & Play Clip</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
