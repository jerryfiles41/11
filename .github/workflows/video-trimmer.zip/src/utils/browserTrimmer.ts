import JSZip from "jszip";

export interface BrowserTrimOptions {
  speed: number;
  volume: number;
  format: string;
  crop: string;
  quality: string;
  watermarkText: string;
  watermarkPosition: string;
  fadeEnabled: boolean;
  audioPitch: string;
}

export interface BrowserTrimResult {
  blob: Blob;
  mimeType: string;
  extension: string;
}

/**
 * Trims a single video part inside the browser using highly stable canvas capture & MediaRecorder.
 * This runs locally on the browser, avoiding large file uploads (413 errors) and produces 100% playable clips.
 */
export async function trimSinglePartInBrowser(
  videoFile: File,
  start: number,
  end: number,
  options: BrowserTrimOptions,
  onProgress: (percent: number) => void
): Promise<BrowserTrimResult> {
  return new Promise(async (resolve, reject) => {
    let videoUrl = "";
    let drawInterval: any = null;
    let checkInterval: any = null;
    let audioCtx: AudioContext | null = null;

    try {
      videoUrl = URL.createObjectURL(videoFile);
      const video = document.createElement("video");
      video.src = videoUrl;
      video.muted = options.volume === 0;
      video.playsInline = true;
      video.crossOrigin = "anonymous";

      // Wait for metadata
      await new Promise<void>((res, rej) => {
        const timeout = setTimeout(() => rej(new Error("Video metadata load timeout")), 8000);
        video.onloadedmetadata = () => {
          clearTimeout(timeout);
          res();
        };
        video.onerror = () => {
          clearTimeout(timeout);
          rej(new Error("Failed to load video file in browser"));
        };
      });

      const totalDuration = end - start;
      if (totalDuration <= 0) {
        throw new Error("Invalid start or end time specified.");
      }

      // Determine dimensions
      const sourceWidth = video.videoWidth || 640;
      const sourceHeight = video.videoHeight || 360;

      // Quality scale factor
      let scale = 1.0;
      if (options.quality === "compressed") {
        scale = 0.6;
      }

      const drawWidth = Math.round(sourceWidth * scale);
      const drawHeight = Math.round(sourceHeight * scale);

      // Crop dimensions adjustment
      let targetWidth = drawWidth;
      let targetHeight = drawHeight;

      if (options.crop === "1:1") {
        targetWidth = Math.min(drawWidth, drawHeight);
        targetHeight = targetWidth;
      } else if (options.crop === "9:16") {
        targetWidth = Math.round(drawHeight * (9 / 16));
        targetHeight = drawHeight;
      } else if (options.crop === "4:3") {
        targetWidth = Math.round(drawHeight * (4 / 3));
        targetHeight = drawHeight;
      }

      const canvas = document.createElement("canvas");
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        throw new Error("Failed to create canvas 2D context.");
      }

      // Configure audio and canvas streams
      const canvasStream = canvas.captureStream(30); // 30 FPS stream
      const combinedStream = new MediaStream();

      // Add video tracks
      canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));

      // Hook up web audio if audio is wanted
      if (options.volume > 0 && options.format !== "mp3") {
        try {
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioContextClass) {
            audioCtx = new AudioContextClass();
            const source = audioCtx.createMediaElementSource(video);
            const gainNode = audioCtx.createGain();
            gainNode.gain.value = options.volume;

            const destNode = audioCtx.createMediaStreamDestination();
            source.connect(gainNode);
            gainNode.connect(destNode);

            destNode.stream.getAudioTracks().forEach((track) => combinedStream.addTrack(track));
          }
        } catch (e) {
          console.warn("Browser Web Audio API initialization skipped (already connected or blocked):", e);
        }
      }

      // Set preservesPitch based on pitch setting
      if (options.audioPitch === "chipmunk" || options.audioPitch === "deep") {
        video.preservesPitch = false;
      } else {
        video.preservesPitch = true;
      }

      // Select recorder mime type
      let mimeType = "";
      const isMp3 = options.format === "mp3";

      if (isMp3) {
        mimeType = "audio/webm;codecs=opus";
      } else if (MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")) {
        mimeType = "video/webm;codecs=vp9,opus";
      } else if (MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")) {
        mimeType = "video/webm;codecs=vp8,opus";
      } else if (MediaRecorder.isTypeSupported("video/mp4;codecs=h264,aac")) {
        mimeType = "video/mp4;codecs=h264,aac";
      } else {
        mimeType = "video/webm";
      }

      const chunks: Blob[] = [];
      const recorder = new MediaRecorder(combinedStream, { mimeType });

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      recorder.onstop = () => {
        const finalMime = recorder.mimeType || mimeType;
        const finalBlob = new Blob(chunks, { type: finalMime });
        
        // Detect extension dynamically from recorded mimetype to guarantee standard players play it
        let ext = ".webm";
        if (isMp3) {
          ext = ".mp3";
        } else if (finalMime.includes("video/mp4")) {
          ext = ".mp4";
        }

        resolve({
          blob: finalBlob,
          mimeType: finalMime,
          extension: ext
        });

        if (audioCtx) {
          audioCtx.close().catch(() => {});
        }
        URL.revokeObjectURL(videoUrl);
      };

      // Playback speed of slicing engine
      // If video is muted or audio-only, we can slice very fast (e.g. 3.0x speed).
      // If audio is active, we run at 1.0x (normal speed) or 1.25x max to ensure
      // flawless real-time audio/video track synchronization.
      const SlicingPlaybackSpeed = (options.volume === 0 || isMp3) ? 3.0 : 1.0;
      video.playbackRate = SlicingPlaybackSpeed;
      video.currentTime = start;

      video.onseeked = () => {
        video.play().catch((err) => console.warn("Background play request:", err));
        recorder.start();

        // High-frequency Canvas Frame Drawer (30 fps)
        drawInterval = setInterval(() => {
          if (video.paused || video.ended) return;

          ctx.clearRect(0, 0, targetWidth, targetHeight);

          // Render centered crop frame from video
          const sx = (video.videoWidth - (targetWidth / scale)) / 2;
          const sy = (video.videoHeight - (targetHeight / scale)) / 2;
          const sw = targetWidth / scale;
          const sh = targetHeight / scale;

          ctx.drawImage(video, sx, sy, sw, sh, 0, 0, targetWidth, targetHeight);

          // Apply Premium watermark overlay if configured
          if (options.watermarkText) {
            ctx.fillStyle = "rgba(255, 255, 255, 0.75)";
            ctx.font = `bold ${Math.max(12, Math.round(targetHeight * 0.04))}px sans-serif`;
            ctx.shadowColor = "black";
            ctx.shadowBlur = 4;

            const textWidth = ctx.measureText(options.watermarkText).width;
            let wx = targetWidth - textWidth - 16;
            let wy = targetHeight - 20;

            if (options.watermarkPosition === "top-left") {
              wx = 16;
              wy = Math.round(targetHeight * 0.08);
            } else if (options.watermarkPosition === "top-right") {
              wx = targetWidth - textWidth - 16;
              wy = Math.round(targetHeight * 0.08);
            } else if (options.watermarkPosition === "bottom-left") {
              wx = 16;
              wy = targetHeight - 20;
            }
            ctx.fillText(options.watermarkText, wx, wy);
            ctx.shadowBlur = 0; // reset
          }

          // Apply transitions (Fade-in / Fade-out overlay)
          if (options.fadeEnabled) {
            const currentOffset = video.currentTime - start;
            let alpha = 0;
            if (currentOffset < 1.0) {
              alpha = 1.0 - currentOffset; // Fade in first 1 second
            } else if (end - video.currentTime < 1.0) {
              alpha = 1.0 - (end - video.currentTime); // Fade out last 1 second
            }
            if (alpha > 0) {
              ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(1.0, Math.max(0, alpha))})`;
              ctx.fillRect(0, 0, targetWidth, targetHeight);
            }
          }

          // Trigger progress updates
          const elapsed = video.currentTime - start;
          const pct = Math.min(100, Math.round((elapsed / totalDuration) * 100));
          onProgress(pct);
        }, 1000 / 30);

        // Periodically verify if video hit bounds
        checkInterval = setInterval(() => {
          if (video.currentTime >= end || video.ended) {
            clearInterval(drawInterval);
            clearInterval(checkInterval);
            video.pause();
            recorder.stop();
          }
        }, 30);
      };

    } catch (err) {
      if (drawInterval) clearInterval(drawInterval);
      if (checkInterval) clearInterval(checkInterval);
      if (audioCtx) audioCtx.close().catch(() => {});
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      reject(err);
    }
  });
}

/**
 * Packs multiple files into a standard, fully compatible ZIP container on the client-side.
 */
export async function createZipBlob(files: { filename: string; blob: Blob }[]): Promise<Blob> {
  const zip = new JSZip();
  files.forEach((file) => {
    zip.file(file.filename, file.blob);
  });
  return await zip.generateAsync({ type: "blob" });
}
