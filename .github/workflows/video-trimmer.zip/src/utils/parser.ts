import { ParsedPart } from "../types";

// Helper: Convert "MM:SS", "HH:MM:SS" or raw seconds string to numerical seconds
export function timeToSeconds(timeStr: string): number {
  const cleaned = timeStr.trim().replace(/[\[\]\(\)]/g, ""); // remove brackets if any
  const parts = cleaned.split(":").map(Number);
  if (parts.some(isNaN)) return 0;
  
  if (parts.length === 3) {
    // HH:MM:SS
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  } else if (parts.length === 2) {
    // MM:SS
    return parts[0] * 60 + parts[1];
  } else if (parts.length === 1) {
    // SS
    return parts[0];
  }
  return 0;
}

// Helper: Convert seconds back to "MM:SS" or "HH:MM:SS" format for visual displays
export function secondsToTimeStr(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return "00:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  if (h > 0) {
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

// Helper: Format file size in bytes to a human-readable format
export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
}

// Parses prompt text and validates against video duration
export function parsePrompt(promptText: string, videoDuration: number): ParsedPart[] {
  const lines = promptText.split("\n");
  const results: ParsedPart[] = [];
  let autoIndex = 1;

  for (let line of lines) {
    const rawLine = line;
    line = line.trim();
    if (!line) continue;

    // Regex to match a time range: either MM:SS-MM:SS, HH:MM:SS-HH:MM:SS, or raw numbers separated by - or to
    // Examples: "1:30 - 1:45", "01:20:15 to 01:21:00", "45-60"
    const timeRangeRegex = /(\d{1,2}:\d{2}(?::\d{2})?|\d+)\s*(?:-|to)\s*(\d{1,2}:\d{2}(?::\d{2})?|\d+)/i;
    const match = line.match(timeRangeRegex);

    if (match) {
      const startStr = match[1];
      const endStr = match[2];
      const startSec = timeToSeconds(startStr);
      const endSec = timeToSeconds(endStr);

      // Extract part index/number from text preceding the timestamps, e.g., "part 1", "p2", "1"
      const beforeText = line.substring(0, match.index).trim();
      let partNum = autoIndex;
      
      const numMatch = beforeText.match(/\d+/);
      if (numMatch) {
        partNum = parseInt(numMatch[0], 10);
      } else {
        autoIndex++;
      }

      // Validations
      let isValid = true;
      let error = "";

      if (startSec >= endSec) {
        isValid = false;
        error = "Start time must be less than end time.";
      } else if (videoDuration > 0 && startSec > videoDuration) {
        isValid = false;
        error = `Start time exceeds video length (${secondsToTimeStr(videoDuration)}).`;
      } else if (videoDuration > 0 && endSec > videoDuration) {
        isValid = false;
        error = `End time exceeds video length (${secondsToTimeStr(videoDuration)}).`;
      }

      results.push({
        partNum,
        startStr,
        endStr,
        startSec,
        endSec,
        rawLine,
        isValid,
        error: error || undefined,
      });
    } else {
      results.push({
        partNum: autoIndex++,
        startStr: "",
        endStr: "",
        startSec: 0,
        endSec: 0,
        rawLine,
        isValid: false,
        error: "No valid time range found (e.g., 1:10-1:25)",
      });
    }
  }

  return results;
}
